import { StatusPage } from "./components/ui/StatusPage";

export default function NotFound() {
    return (
        <StatusPage type="404" />
    );
}
