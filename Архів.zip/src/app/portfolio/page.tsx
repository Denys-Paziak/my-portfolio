import { metadata } from "./metadata";
import PortfolioContent from "./PortfolioContent";

export { metadata };

export default function PortfolioPage() {
    return <PortfolioContent />;
}
