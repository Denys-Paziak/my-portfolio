import { metadata } from "./metadata";
import ServicesContent from "./ServicesContent";

export { metadata };

export default function ServicesPage() {
    return <ServicesContent />;
}
