import { metadata } from "./metadata";
import BlogContent from "./BlogContent";

export { metadata };

export default function BlogPage() {
    return <BlogContent />;
}
